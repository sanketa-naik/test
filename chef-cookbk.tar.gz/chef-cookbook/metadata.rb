name 'chef-cookbook'
maintainer 'REAN Cloud'
maintainer_email 'rahul.patil@reancloud.com'
license 'All Rights Reserved'
description 'Installs/Configures chef-cookbook'
long_description 'Installs/Configures chef-cookbook'
version '0.1.0'

