
default["chef-cookbook"]["attributeData"] = "attributeValue"
