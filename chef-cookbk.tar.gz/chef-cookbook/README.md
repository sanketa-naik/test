chef-cookbook cookbook [Github]
=====================

Cookbook to execute linux and windows commands 

License and Authors
-------------------
License: Owned by REAN. Do not copy or use without permission from REAN
Authors: REAN

